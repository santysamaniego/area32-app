
import { createClient } from '@supabase/supabase-js';

// ------------------------------------------------------------------
// CONFIGURACIÓN DE SUPABASE
// ------------------------------------------------------------------
// 1. Ve a https://supabase.com, crea un proyecto.
// 2. En Settings > API, copia la "Project URL" y la "anon public key".
// 3. Reemplaza los valores abajo.
// ------------------------------------------------------------------

const supabaseUrl = 'https://TU_PROJECT_URL_AQUI.supabase.co';
const supabaseKey = 'TU_ANON_PUBLIC_KEY_AQUI';

export const supabase = createClient(supabaseUrl, supabaseKey);
